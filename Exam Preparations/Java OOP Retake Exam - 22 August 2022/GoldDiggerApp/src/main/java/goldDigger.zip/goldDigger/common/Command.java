package goldDigger.common;

public enum Command {
    AddDiscoverer,
    AddSpot,
    ExcludeDiscoverer,
    InspectSpot,
    GetStatistics,
    Exit,
}
